package p0421;

import java.util.Scanner;

public class exam08 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int card = 10000; // 교통카드 잔액
		int x;
//		do {
//			System.out.printf("교통카드 잔액 : %d\n", card);
//			System.out.printf("사용할 금액을 입력하세요. : \n");
//			int num = sc.nextInt(); 
//			x = card-num;
//			System.out.printf("교통카드 잔액 : %d\n", x);
//		}while(x<1300);
//		System.out.printf("잔액이 부족해 교통카드를 사용할 수 없습니다.");
		System.out.printf("교통카드 잔액 : %d\n", card);
		while(true) {
			System.out.printf("사용할 금액을 입력하세요. : ");
			int num = sc.nextInt();
//			System.out.println();
			card -= num;
			System.out.printf("교통카드 잔액: %d\n", card);
			if(card<1300) {
				break;
			}
		}
		System.out.printf("잔액이 부족해 교통카드를 사용할 수 없습니다.");
		
	}

}

package p0429;

public class Exam04 {

	public static void main(String[] args) {
		int x = 63;
		int y = 18;
		int z = 52;
		int sum = x + y + z; // 합계
		int avg = sum / 3; // 평균
		System.out.printf("x값은 %d입니다.\n", x);
		System.out.printf("y값은 %d입니다.\n", y);
		System.out.printf("z값은 %d입니다.\n", z);
		System.out.printf("합계는 %d입니다.\n", sum);
		System.out.printf("평균은 %d입니다.", avg);
	}

}

package p0429;

public class Exam01 {

	public static void main(String[] args) {
		System.out.printf("첫 Java 프로그램입니다.\n화면에 출력하고 있습니다.");
	}

}

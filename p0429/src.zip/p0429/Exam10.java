package p0429;

import java.util.Scanner;

public class Exam10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("주소:");
		String line = sc.nextLine();
		System.out.printf("주소는 %s입니다.", line);
	}

}

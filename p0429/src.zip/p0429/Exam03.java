package p0429;

public class Exam03 {

	public static void main(String[] args) {
		int x = 63;
		int y = 18;
		int sum = x + y; // 합계
		int avg = sum/2; // 평균
		System.out.printf("x값은 %d입니다.\n", x);
		System.out.printf("y값은 %d입니다.\n", y);
		System.out.printf("합계는 %d입니다.\n", sum);
		System.out.printf("평균은 %d입니다.", avg);
	}

}

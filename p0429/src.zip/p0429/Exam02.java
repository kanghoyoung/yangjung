package p0429;

public class Exam02 {

	public static void main(String[] args) {
		System.out.println("강");
		System.out.println("호");
		System.out.println("영");
	}

}
